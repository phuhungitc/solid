var App = {

};
jQuery(document).ready(function(){

});